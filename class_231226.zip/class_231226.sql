-- 13.209.226.204
-- id: edu1 ~ edu12
-- pw: sesac

USE product;

SELECT * FROM prod_order LIMIT 5;
SELECT * FROM holidays;

SELECT count(*) FROM prod_order;
SELECT count(DISTINCT order_no) FROM prod_order;
-- 3431, 3215

SELECT min(order_dt) AS dt_start, max(order_dt) AS dt_end
FROM prod_order;

SELECT DISTINCT product_name FROM prod_order;
SELECT DISTINCT `options` FROM prod_order;
SELECT min(qty) AS `min`, round(avg(qty), 3) AS `avg`, max(qty) AS `max`
FROM prod_order;

SELECT * FROM prod_order WHERE qty >= 2;
SELECT count(*) FROM prod_order WHERE qty >= 2;
SELECT count(DISTINCT order_no) FROM prod_order WHERE qty >= 2;

SELECT DISTINCT `options` FROM prod_order WHERE qty >= 2;
SELECT `options`, count(*) AS cnt 
FROM prod_order WHERE qty >= 2 GROUP BY `options`
ORDER BY cnt DESC;

SELECT year(order_dt) FROM prod_order LIMIT 5;
SELECT year(order_dt) AS year FROM prod_order LIMIT 5;
SELECT year(order_dt) AS `year`, count(*) AS cnt
FROM prod_order GROUP BY YEAR(order_dt);

SELECT year(order_dt) AS y, month(order_dt) AS m, count(*) AS cnt
FROM prod_order GROUP BY YEAR(order_dt), month(order_dt);

SELECT year(order_dt) AS y, month(order_dt) AS m, sum(qty) AS cnt
FROM prod_order GROUP BY YEAR(order_dt), month(order_dt);

SELECT DATE_FORMAT(order_dt, "%Y-%m-%d") AS date 
FROM prod_order LIMIT 5;

SELECT DATE_FORMAT(order_dt, "%Y-%m") AS yyyymm 
FROM prod_order LIMIT 5;

SELECT DATE_FORMAT(order_dt, "%Y-%m") AS yyyymm, count(*) AS cnt
FROM prod_order GROUP BY DATE_FORMAT(order_dt, "%Y-%m");

SELECT DATE_FORMAT(order_dt, "%Y-%m-%d") AS ymd, count(*) AS cnt
FROM prod_order GROUP BY DATE_FORMAT(order_dt, "%Y-%m-%d");

SELECT order_dt, DAYOFWEEK(order_dt) FROM prod_order LIMIT 5; 

-- 주중(2, 3, 4, 5, 6): 2583
SELECT count(*) FROM prod_order 
WHERE DAYOFWEEK(order_dt) BETWEEN 2 AND 6;

-- 주말(7, 1): 848
SELECT count(*) FROM prod_order 
WHERE DAYOFWEEK(order_dt) IN (7, 1);

SELECT count(*) FROM prod_order;

SELECT count(DISTINCT DAYOFWEEK(order_dt)) FROM prod_order;

-- 시간대별 주문건 수 집계
SELECT HOUR(order_dt) AS H, count(*) FROM prod_order 
GROUP BY hour(order_dt);

SELECT * FROM prod_order;

SELECT * FROM holidays;

SELECT LENGTH(order_no) FROM prod_order LIMIT 5;
SELECT DISTINCT LENGTH(order_no) FROM prod_order;

SELECT * FROM prod_order LIMIT 5;
SELECT left(`options`, 3) FROM prod_order LIMIT 5;
SELECT DISTINCT left(`options`, 3) FROM prod_order;

SELECT left(`options`, 3) AS `option`, count(*) AS cnt
FROM prod_order GROUP BY left(`options`, 3);

SELECT left(`options`, 3) AS `option`, count(*) AS cnt
FROM prod_order WHERE year(order_dt) = 2023
GROUP BY left(`options`, 3);

SELECT left(`options`, 3) AS `color`, count(*) AS cnt
FROM prod_order WHERE DATE_FORMAT(order_dt, "%Y-%m") = "2023-07"
GROUP BY left(`options`, 3);

SELECT DISTINCT right(`options`, 2) FROM prod_order;

SELECT trim(right(`options`, 2)) AS `size`, count(*) AS cnt
 FROM prod_order WHERE DATE_FORMAT(order_dt, "%Y-%m") = "2023-07"
 GROUP BY right(`options`, 2);


