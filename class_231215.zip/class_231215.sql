-- 테이블의 행 개수를 확인하는 쿼리
select count(*) from data_netflix_program;

-- 첫 5개 row 출력
select * from data_netflix_program limit 5;

-- "data_netflix_program"테이블의
-- "country_iso2" 변수의 값이 "JP"인 행(모든 열)
select * from data_netflix_program 
where country_iso2 = "JP";

-- where 조건을 만족하는 행의 개수
select count(*) from data_netflix_program 
where country_iso2 = "GR";

-- != 은 "not equal" 이라고 읽음
select count(*) from data_netflix_program 
where country_iso2 != "GR";

select * from data_netflix_program
where weekly_rank = 1;

select count(*) from data_netflix_program
where weekly_rank = 1;

select count(*) from data_netflix_program
where weekly_rank >= 10;

select count(*) from data_netflix_program
where weekly_rank = 10;

select count(*) from edu1.data_netflix_program 
where weekly_rank = 10;

-- Python .isin()
-- R %in%

select * from data_netflix_program 
where country_iso2 in ("ES", "JO");

select count(*) from data_netflix_program 
where country_iso2 in ("ES", "JO", "JP");

-- "weekly_rank" 필드의 값이 5이상 6이하
select * from data_netflix_program
where weekly_rank between 5 and 6;

select count(*) from data_netflix_program
where weekly_rank between 5 and 6;


select * from data_netflix_program dnp limit 10;

select * from data_netflix_program
where show_title like "How%";

select * from how_test where text like "How%";
select * from how_test where text like "how%";
select * from how_test where text like "%How";
select * from how_test where text like "% How";
select * from how_test where text like "How";
select * from how_test where text = "How";
select * from how_test where text in ("How", "abcHow");

-- 조건 A, 조건 B
-- AND: A조건을 만족하면서 B조건을 만족하는 경우. 즉, 모든 조건을 만족해야 TRUE
-- OR: A조건을 만족하거나 B조건을 만족하는 경우. 적어도 하나의 조건만 만족해도 TRUE

-- ("ES", "JO")
select * from data_netflix_program 
where country_iso2 = "ES" and country_iso2 = "JO";

select * from data_netflix_program 
where country_iso2 = "ES" or country_iso2 = "JO";

select * from data_netflix_program 
where country_iso2 = "ES" and weekly_rank = 1;

select * from data_netflix_program 
where (country_iso2 = "ES") and weekly_rank = 1;

select * from data_netflix_program
where show_title = "Squid Game";

select count(*) from data_netflix_program
where show_title = "Squid Game";

-- "show_title"의 값이 "Squid Game"이면서 
-- "weekly_rank"의 값이 10인 것을 필터링 하시오.
select * from data_netflix_program
where show_title = "Squid Game" and weekly_rank = 10;

select * from data_netflix_program
where show_title = "Squid Game" and country_name = "Russia";

select * from data_netflix_program
where cumulative_weeks_in_top_10 >= 90;


select count(*) from data_elec_load 

-- wide form 데이터(반대는 long form)
select * from data_elec_load limit 5;

select * from data_elec_load where year >= 2017;

select * from data_elec_load 
where year >= 2017 and month = 9;

SELECT * FROM data_elec_load
WHERE YEAR = 2017 or year = 2016;

-- 성적데이터(data_class_scores)
-- Q1. 남학생 숫자는? A: 314
select count(*) from data_class_scores
where gender = "M";

-- Q2. 여학생 숫자는? A: 286
select count(*) from data_class_scores
where gender = "F";

-- Q3. 2학년 남학생 숫자는? (grade 참고) A: 110
select count(*) from data_class_scores
where grade = 2 and gender = "M";



