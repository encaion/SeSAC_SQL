select * from data_join_customers djc ;
select * from data_join_orders djo ;

-- Primary key(PK), Foreign key(FK) 지정
-- Error
-- alter table data_join_customers add primary key customer_id;
alter table data_join_customers add primary key (customer_id);
desc data_join_customers;

alter table data_join_orders add foreign key (customer_id)
references data_join_customers(customer_id);
desc data_join_orders;

-- alter table data_join_customers drop primary key (customer_id);
-- alter table data_join_customers drop primary key;
desc data_join_customers;

-- primary key는 foreign key와 연결되어 있을 경우
-- 바로 삭제(drop)이 되지 않음. 그래서 foreign key를 먼저 제거해야 함.
-- alter table data_join_orders drop foreign key;
-- alter table data_join_orders drop foreign key customer_id;
-- alter table data_join_orders drop foreign key (customer_id);

select * from information_schema.key_column_usage limit 2;

select TABLE_NAME, COLUMN_NAME, CONSTRAINT_NAME  
from information_schema.key_column_usage limit 2;

alter table data_join_orders 
drop foreign key data_join_orders_ibfk_1;
desc data_join_orders;

select TABLE_NAME, COLUMN_NAME, CONSTRAINT_NAME  
from information_schema.key_column_usage 
where TABLE_NAME like "data_join%";

alter table data_join_customers drop primary key;
desc data_join_customers;

-- PK는 중복을 허용하지 않기 때문에 에러가 발생함.
alter table data_join_orders add primary key (customer_id);
select customer_id, sum(1) as cnt from data_join_orders
group by customer_id;

alter table data_join_orders add primary key (order_id);
desc data_join_orders;
select * from data_join_orders djo limit 2;

select count(*) from netflix_show_a;
select count(*) from netflix_show_b;

select * from netflix_show_a limit 2;
select * from netflix_show_b limit 2;

select `index`, runtime from netflix_show_b limit 2;

alter table netflix_show_a add primary key (`index`);
desc netflix_show_a;

-- 무결성 에러.
alter table netflix_show_b add foreign key (`index`)
references netflix_show_a(`index`);

select count(*) from netflix_show_c;
alter table netflix_show_c add foreign key (`index`)
references netflix_show_a(`index`);
desc netflix_show_c;

select TABLE_NAME, COLUMN_NAME, CONSTRAINT_NAME  
from information_schema.key_column_usage 
where TABLE_NAME like "netflix_show%";

alter table netflix_show_c drop foreign key netflix_show_c_ibfk_1;

alter table netflix_show_c 
add constraint tbl_c_fk1 foreign key (`index`)
references netflix_show_a(`index`);

select * from netflix_show_a join netflix_show_b 
on netflix_show_a.`index` = netflix_show_b.`index`;

select * from netflix_show_a as tbl_a join netflix_show_b as tbl_b
on tbl_a.`index` = tbl_b.`index`;

select count(*) from netflix_show_a as tbl_a join netflix_show_b as tbl_b
on tbl_a.`index` = tbl_b.`index`;

select `index`, id
from netflix_show_a as tbl_a join netflix_show_b as tbl_b
on tbl_a.`index` = tbl_b.`index`;

select tbl_a.`index`, id
from netflix_show_a as tbl_a join netflix_show_b as tbl_b
on tbl_a.`index` = tbl_b.`index`;

select tbl_a.`index`, tbl_a.id
from netflix_show_a as tbl_a join netflix_show_b as tbl_b
on tbl_a.`index` = tbl_b.`index`;

select tbl_b.*, tbl_a.id
from netflix_show_a as tbl_a join netflix_show_b as tbl_b
on tbl_a.`index` = tbl_b.`index`;

select * from data_join_a;
select * from data_join_b;
select * from data_join_a dja join data_join_b djb 
on dja.location = djb.location;

select * from data_join_a dja join data_join_b djb 
on dja.location = djb.location and dja.`hour` = djb.`hour`;

select dja.*, djb.manager, djb.`check` 
from data_join_a dja join data_join_b djb 
on dja.location = djb.location and dja.`hour` = djb.`hour`;

select dja.*, djb.manager, djb.`check` 
from data_join_a dja left join data_join_b djb 
on dja.location = djb.location and dja.`hour` = djb.`hour`;

select * 
from data_join_a dja left join data_join_b djb 
on dja.id = djb.id;
