SELECT * FROM tbl
WHERE name = "abc";

SELECT * FROM tbl
WHERE id > 10000000 AND name = "abc";

SELECT * FROM tbl
WHERE year(order_dt) > 2022 AND name = "abc";

SELECT min(id) FROM tbl
WHERE year(order_dt) = 2022

-- 12341234
SELECT * FROM tbl
WHERE id >= 12341234 AND name = "abc";

SELECT * FROM data_diamonds LIMIT 5;

SELECT now(6);
SET @start_time = now(6);
SELECT * FROM data_diamonds WHERE color IN ("I", "H");
SET @end_time = now(6);

SELECT timediff(@end_time, @start_time) AS time; 
-- 0.18 초 정도...

ALTER TABLE data_diamonds ADD INDEX (color);
DESC data_diamonds;


SET @start_time = now(6);
SELECT * FROM data_diamonds WHERE color IN ("I", "H");
SET @end_time = now(6);

SELECT timediff(@end_time, @start_time) AS time; 

-- 사용자 지정 변수 목록 확인
SELECT * FROM information_schema.USER_VARIABLES;

SET @val_1 = 2;
SELECT @val_1;

SELECT color, count(*) FROM data_diamonds GROUP BY color;

SET @val_color = "G";
SELECT count(*) FROM data_diamonds WHERE color = @val_color;
SELECT avg(price) FROM data_diamonds WHERE color = @val_color;

SELECT avg(price) INTO @price_avg FROM data_diamonds;
SELECT @price_avg;
SELECT count(*) FROM data_diamonds WHERE price >= @price_avg;

-- SELECT price INTO @price_avg2 FROM data_diamonds;
SELECT price INTO @price_avg2 FROM data_diamonds LIMIT 1;
SELECT @price_avg2;

CREATE TABLE tbl (
  id int AUTO_INCREMENT PRIMARY KEY,
  name varchar(20),
  age int,
  email varchar(50)
);

INSERT INTO tbl (name, age, email) VALUES ("A", 25, "abc@gmail.com");
INSERT INTO tbl (name, age, email) VALUES (NULL, 30, "efg@gmail.com");
INSERT INTO tbl (name, age, email) VALUES ("C", 35, "hij@gmail.com");
INSERT INTO tbl (name, age, email) VALUES ("D", NULL, "aaa@gmail.com");
INSERT INTO tbl (name, age, email) VALUES (NULL, NULL, "zzz@gmail.com");
-- INSERT INTO tbl (age, name, email) VALUES (123, NULL, "bbb@gmail.com");

SELECT * FROM tbl;

SELECT * FROM tbl WHERE name IS NULL;
SELECT * FROM tbl WHERE name IS NOT NULL;
SELECT count(*) FROM tbl WHERE name IS NULL;

SELECT
	count(CASE WHEN name  IS NULL THEN 1 end) AS v2,
	count(CASE WHEN age   IS NULL THEN 1 end) AS v3,
	count(CASE WHEN email IS NULL THEN 1 end) AS v4
FROM tbl;

SELECT
	count(CASE WHEN name  IS NULL THEN 1 end) AS v2,
	count(CASE WHEN age   IS NULL THEN 1 end) AS v3,
	count(CASE WHEN email IS NULL THEN 1 end) AS v4
FROM tbl WHERE id < 4;

SELECT * FROM tbl;

UPDATE tbl SET name = "B" WHERE id = 2;
SELECT * FROM tbl;

UPDATE tbl SET name = "E" WHERE name IS NULL;
SELECT * FROM tbl;

-- DROP TABLE tbl;
 
SELECT *, ifnull(age, 0) AS age_f FROM tbl;
SELECT *, coalesce(age, 0) AS age_f FROM tbl;

SELECT avg(age) INTO @age_avg FROM tbl;
SELECT *, ifnull(age, @age_avg) AS age_f FROM tbl;
SELECT stddev(ifnull(age, @age_avg)) AS age_f FROM tbl;

SELECT * FROM tbl;

-- coalesce() 함수는 row 방향으로 동작하며 결측이 발생할 경우 다음 원소를 반환하고
-- 모두 결측(NULL)인 경우는 지정한 값을 반환한다. (다음의 쿼리에서는 "-")
SELECT COALESCE(age, email, "-") FROM tbl;
