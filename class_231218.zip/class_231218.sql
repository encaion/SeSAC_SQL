select count(*) from data_diamonds;
select count(*) from data_diamonds 
where carat >= 2;
select * from data_diamonds limit 3;
select min(carat), max(carat) from data_diamonds;
select avg(carat) from data_diamonds;
select round(avg(carat), 1), round(avg(carat), 3)
from data_diamonds;

-- 별칭(alias)
select round(avg(carat) * 100, 1) from data_diamonds;
select round(avg(carat) * 100, 1) as v1 from data_diamonds;

select carat as v1, cut as v2 from data_diamonds limit 2;

select count(*) from data_diamonds 
where floor(carat) = 1;

select count(*) from data_diamonds
where carat >= 1 and carat < 2;

select count(*) from data_diamonds 
where floor(carat * 2) = 1;

select count(*) from data_diamonds
where carat >= 0.5 and carat < 1;

select pow(1, 200), pow(1.01, 200);

-- group by
select * from data_diamonds group by cut; -- 세공수준별 ~
-- cut 원소의 개수를 센 것과 같고 count() 함수를 특정 변수의 원소에 적용한 것과 같음. 
select sum(1), cut from data_diamonds group by cut;
select count(*) from data_diamonds where cut = "Good";
select count(*) from data_diamonds where cut = "Ideal";

-- 세공수준별 carat의 평균
select avg(carat) from data_diamonds group by cut;
select cut, avg(carat) from data_diamonds group by cut;
select cut, round(avg(carat), 2) as carat_avg 
from data_diamonds group by cut;

-- 세공수준별 price의 평균
select cut, avg(price) from data_diamonds group by cut;

-- 세공수준별 price 최댓값
select cut, max(price) from data_diamonds group by cut;

select max(carat), avg(carat), stddev(carat) from data_diamonds;

-- carat의 평균값에 carat의 2 표준편차를 더한 값 보다 큰 carat값을 가지는 다이아몬드는
-- 총 몇 개 인가?
-- avg(x) + 2 * stddev(x)

select avg(carat) + 2 * stddev(carat) from data_diamonds;
select count(*) from data_diamonds where carat > 1.745953;

select avg(carat) + 2 * stddev(carat) from data_diamonds;
-- 
select count(*) from data_diamonds where carat > (
	select avg(carat) + 2 * stddev(carat) from data_diamonds
);

select avg(carat) as carat_avg, stddev(carat) as carat_stddev from data_diamonds;
-- CTE(공통 테이블 표현식, Common Table Expression). 즉, 임시 테이블을 생성하는 것과 같음
with stats as (
	select avg(carat) as carat_avg, stddev(carat) as carat_stddev from data_diamonds
)
select count(*) from data_diamonds, stats
where carat > (carat_avg + 2 * carat_stddev);

-- 세공수준별(cut), 색상별(color) 다이아몬드 price 평균
select cut, color, avg(price) from data_diamonds group by cut, color;
-- 세공수준별(cut), 색상별(color) 다이아몬드 price 평균을 산출하고
--   cut, color 그리고 반올림하여 소수점 둘째 자리까지 표기된 price의 평균이 최종 출력되도록 하시오.
select cut, color, round(avg(price), 2) from data_diamonds group by cut, color;

select cut, color, round(avg(price), -2) from data_diamonds group by cut, color;

-- 세공수준별(cut), 색상별(color) 다이아몬드 carat 평균
select cut, color, avg(carat) from data_diamonds group by cut, color;

-- 세공수준별(cut), 색상별(color) 다이아몬드 carat 최솟값
select cut, color, min(carat) from data_diamonds group by cut, color;

-- 색상별(color), 세공수준별(cut) 다이아몬드 price 최댓값
select color, cut, max(price) from data_diamonds group by color, cut;


-- 중복 제거
select distinct color from data_diamonds;
select distinct cut from data_diamonds;
select distinct color, cut from data_diamonds;

select color, cut, sum(1) as cnt from data_diamonds group by color, cut;

-- order by
select * from data_diamonds order by price;
select * from data_diamonds order by price desc;

select * from data_diamonds order by price limit 3;
select * from data_diamonds order by price desc limit 3;

select * from data_diamonds where cut = "Ideal" order by price desc limit 3;

select * from data_diamonds limit 2;



