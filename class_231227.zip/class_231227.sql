-- 로컬 서버 작성 쿼리
USE edu1;

SELECT * FROM data_diamonds LIMIT 4;

SELECT * FROM (
  SELECT cut, avg(price) AS price
  FROM data_diamonds 
  GROUP BY cut
) AS tbl_g WHERE price > 4000;

SELECT cut, avg(price) AS price
  FROM data_diamonds 
  GROUP BY cut;
  
 SELECT * FROM (
  SELECT cut, avg(price) AS price
  FROM data_diamonds
  WHERE price > 4000
  GROUP BY cut
) AS tbl_g;

SELECT * FROM data_diamonds AS d1
WHERE price > (
  SELECT avg(price) FROM data_diamonds AS d2
  WHERE d1.cut = d2.cut
);

SELECT color, avg(price) FROM data_diamonds GROUP BY color;

SELECT * FROM (
  SELECT color, avg(price) AS price
  FROM data_diamonds GROUP BY color
) AS t1 WHERE price > 5000;

SELECT cut, avg(price) AS price FROM data_diamonds 
WHERE color IN ("I", "J") 
GROUP BY cut;

SELECT color FROM (
  SELECT color, avg(price) AS price
  FROM data_diamonds GROUP BY color
) AS t1 WHERE price > 5000;

SELECT cut, avg(price) AS price FROM data_diamonds 
WHERE color IN (
  SELECT color FROM (
    SELECT color, avg(price) AS price
    FROM data_diamonds GROUP BY color
) AS t1 WHERE price > 5000) 
GROUP BY cut;

SELECT * FROM data_diamonds LIMIT 5;

SELECT DISTINCT color FROM data_diamonds
WHERE color IN ("E", "J");

SELECT DISTINCT color FROM data_diamonds
WHERE color NOT IN ("E", "J");

-- 원격 서버 작성 쿼리
SELECT * FROM prod_order 
WHERE DATE_FORMAT(order_dt, "%Y-%m-%d") IN ("2023-12-01", "2023-12-02"); 

SELECT count(*) FROM prod_order 
WHERE DATE_FORMAT(order_dt, "%Y-%m-%d") IN ("2023-12-01", "2023-12-02"); 

SELECT count(*) FROM prod_order 
WHERE DATE_FORMAT(order_dt, "%Y-%m-%d") NOT IN ("2023-12-01", "2023-12-02"); 

SELECT * FROM prod_order 
WHERE DATE_FORMAT(order_dt, "%Y-%m-%d") IN (
  SELECT holiday FROM holidays
); 

SELECT DISTINCT DATE_FORMAT(order_dt, "%Y-%m-%d") AS date 
FROM prod_order 
WHERE DATE_FORMAT(order_dt, "%Y-%m-%d") IN (
  SELECT holiday FROM holidays
); 

SELECT DISTINCT DATE_FORMAT(order_dt, "%Y-%m-%d") AS date 
FROM prod_order 
WHERE DATE_FORMAT(order_dt, "%Y-%m-%d") IN (
  SELECT holiday FROM holidays
  WHERE holiday >= "2023-01-01"
) ORDER BY date; 

SELECT DATE_FORMAT(order_dt, "%Y-%m-%d") AS date, sum(qty) AS qty  
FROM prod_order 
WHERE DATE_FORMAT(order_dt, "%Y-%m-%d") IN (
  SELECT holiday FROM holidays
  WHERE holiday >= "2023-01-01"
) 
GROUP BY DATE_FORMAT(order_dt, "%Y-%m-%d"); 

SELECT round(avg(qty), 1) AS qty_mean
FROM (
  SELECT DATE_FORMAT(order_dt, "%Y-%m-%d") AS date, sum(qty) AS qty  
  FROM prod_order 
  WHERE DATE_FORMAT(order_dt, "%Y-%m-%d") IN (
    SELECT holiday FROM holidays
    WHERE holiday >= "2023-01-01"
  ) 
  GROUP BY DATE_FORMAT(order_dt, "%Y-%m-%d")
) AS tbl;

SELECT round(avg(qty), 1) AS qty_mean
FROM (
  SELECT DATE_FORMAT(order_dt, "%Y-%m-%d") AS date, sum(qty) AS qty  
  FROM prod_order 
  WHERE DATE_FORMAT(order_dt, "%Y-%m-%d") NOT IN (
    SELECT holiday FROM holidays
    WHERE holiday >= "2023-01-01"
  ) 
  GROUP BY DATE_FORMAT(order_dt, "%Y-%m-%d")
) AS tbl;


-- 주말의 일별 주문 수량 집계
SELECT DATE_FORMAT(order_dt, "%Y-%m-%d") AS date, sum(qty) AS qty  
FROM prod_order 
WHERE DAYOFWEEK(order_dt) IN (7, 1)
GROUP BY DATE_FORMAT(order_dt, "%Y-%m-%d");

SELECT DATE_FORMAT(order_dt, "%Y-%m-%d") AS date, 
  DAYOFWEEK(order_dt) AS wday,
  sum(qty) AS qty  
FROM prod_order 
WHERE DAYOFWEEK(order_dt) IN (7, 1)
GROUP BY DATE_FORMAT(order_dt, "%Y-%m-%d");

SELECT DATE_FORMAT(order_dt, "%Y-%m-%d") AS date, 
  DAYOFWEEK(order_dt) AS wday,
  sum(qty) AS qty  
FROM prod_order 
WHERE DAYOFWEEK(order_dt) IN (7, 1) AND year(order_dt) = 2023
GROUP BY DATE_FORMAT(order_dt, "%Y-%m-%d");

SELECT avg(qty) AS qty_mean FROM (
  SELECT DATE_FORMAT(order_dt, "%Y-%m-%d") AS date, sum(qty) AS qty  
  FROM prod_order 
  WHERE DAYOFWEEK(order_dt) IN (7, 1) AND year(order_dt) = 2023
  GROUP BY DATE_FORMAT(order_dt, "%Y-%m-%d")
) AS tbl

SELECT avg(qty) AS qty_mean FROM (
  SELECT DATE_FORMAT(order_dt, "%Y-%m-%d") AS date, sum(qty) AS qty  
  FROM prod_order 
  WHERE DAYOFWEEK(order_dt) NOT IN (7, 1) AND year(order_dt) = 2023
  GROUP BY DATE_FORMAT(order_dt, "%Y-%m-%d")
) AS tbl

SELECT * FROM prod_order LIMIT 2;
SELECT * FROM holidays LIMIT 2;

SELECT * FROM prod_order JOIN holidays
ON prod_order.order_dt = holidays.holiday;

SELECT * FROM prod_order JOIN holidays
ON DATE_FORMAT(prod_order.order_dt, "%Y-%m-%d")  = holidays.holiday;

SELECT prod_order.* FROM prod_order JOIN holidays
ON DATE_FORMAT(prod_order.order_dt, "%Y-%m-%d")  = holidays.holiday;

SELECT prod_order.*, holidays.description FROM prod_order JOIN holidays
ON DATE_FORMAT(prod_order.order_dt, "%Y-%m-%d")  = holidays.holiday;

SELECT tbl_p.*, holidays.description 
FROM (SELECT * FROM prod_order WHERE YEAR(order_dt) = 2023) AS tbl_p JOIN holidays
ON DATE_FORMAT(tbl_p.order_dt, "%Y-%m-%d") = holidays.holiday;

SELECT DATE_FORMAT(t.order_dt, "%Y-%m-%d") AS `date`, sum(t.qty) AS qty_sum FROM (
  SELECT tbl_p.*, holidays.description 
  FROM (SELECT * FROM prod_order WHERE YEAR(order_dt) = 2023) AS tbl_p JOIN holidays
  ON DATE_FORMAT(tbl_p.order_dt, "%Y-%m-%d") = holidays.holiday
) AS t GROUP BY DATE_FORMAT(t.order_dt, "%Y-%m-%d");

SELECT `date`, sum(t.qty) AS qty_sum FROM (
  SELECT tbl_p.*, DATE_FORMAT(tbl_p.order_dt, "%Y-%m-%d") AS date, holidays.description 
  FROM (SELECT * FROM prod_order WHERE YEAR(order_dt) = 2023) AS tbl_p JOIN holidays
  ON DATE_FORMAT(tbl_p.order_dt, "%Y-%m-%d") = holidays.holiday
) AS t GROUP BY t.date;

SELECT t.date, sum(t.qty) AS qty_sum FROM (
  SELECT tbl_p.*, holidays.description 
  FROM (SELECT *, DATE_FORMAT(order_dt, "%Y-%m-%d") AS date
        FROM prod_order WHERE YEAR(order_dt) = 2023) AS tbl_p JOIN holidays
  ON tbl_p.`date` = holidays.holiday
) AS t GROUP BY t.date;
-- Unknown column 'tbl_p.date' in 'on clause'
